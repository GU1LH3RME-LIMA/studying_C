
package telausuario;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;


public class LogarSistema extends JFrame {

    public LogarSistema() {
        initComponents();
        
    }
        private void logar(){
               try{
                String senha = String.valueOf(senhaCampo.getPassword());
                String nome = usuarioCampo.getText();
           Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuario", "root", "root");
            String sql = "select * from pessoa where email=? and senha=?";
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setString(1, nome);
            stm.setString(2, senha);
            ResultSet rs = stm.executeQuery();
            if (rs.next())
            {
               if(nome.equals("Admin@admin.com")){
                    JOptionPane.showMessageDialog(null, "Logado com sucesso!");
                    cad usuarioTela = new cad();                    
                    usuarioTela.setVisible(true);
                    dispose();
               }if(nome.equals(rs)){
                    JOptionPane.showMessageDialog(null, "Logado com sucesso!");
                    //ProfessorTela profTela = new ProfessorTela();  
                    //profTela.setVisible(true);
                    //dispose();*/
                }
            } else
            {   
                   JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos!!");
            }
                    
                
}catch(Exception CommunicationsException){            
                  JOptionPane.showMessageDialog(null, "Erro ao se comunicar com o banco de dados");
}
        }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {
setSize (500,200);
     setLocation (500,200);
        jPanel1 = new javax.swing.JPanel();
        usuarioCampo = new javax.swing.JTextField();
        senhaCampo = new javax.swing.JPasswordField();
        entrarBotao = new javax.swing.JButton();
        usuarioLabel = new javax.swing.JLabel();
        senhaLabel = new javax.swing.JLabel();
        sairBotao = new javax.swing.JButton();
        tituloLabel = new javax.swing.JLabel();
        background = new javax.swing.JLabel();
jPanel1.setBackground(new Color(239, 228, 174));
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login do Sistema");
        setLocationByPlatform(true);
        setResizable(false);
         entrarBotao.setIcon( new ImageIcon(
                getClass().getResource(
                "/icones/tick.png")));
     sairBotao.setIcon(new ImageIcon(
                getClass().getResource(
                "/icones/sair.png")));
     tituloLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icones/DNV_Easy-Resize.com (2).jpg")));

        jPanel1.setLayout(null);

        usuarioCampo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        usuarioCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                usuarioCampoKeyPressed(evt);
            }
        });
        jPanel1.add(usuarioCampo);
        usuarioCampo.setBounds(70,40,180,20);

        senhaCampo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        senhaCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                senhaCampoKeyPressed(evt);
            }
        });
        jPanel1.add(senhaCampo);
        senhaCampo.setBounds(70,70,180,20);

        entrarBotao.setBackground(new java.awt.Color(0, 102, 0));
        entrarBotao.setText("Entrar");
        entrarBotao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarBotaoActionPerformed(evt);
            }
        });
        entrarBotao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                entrarBotaoKeyPressed(evt);
            }
        });
        jPanel1.add(entrarBotao);
        entrarBotao.setBounds(40,110,100,20);

        usuarioLabel.setForeground(new java.awt.Color(0, 0, 0));
        usuarioLabel.setText("E-Mail:");
        jPanel1.add(usuarioLabel);
        usuarioLabel.setBounds(20,20,150,60);

        senhaLabel.setForeground(new java.awt.Color(0, 0, 0));
        senhaLabel.setText("Senha:");
        jPanel1.add(senhaLabel);
        senhaLabel.setBounds(20,50,150,60);

        sairBotao.setBackground(new java.awt.Color(255, 0, 0));
        sairBotao.setText("Sair");
        sairBotao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairBotaoActionPerformed(evt);
            }
        });
        jPanel1.add(sairBotao);
        sairBotao.setBounds(150,110,100,20);

        tituloLabel.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        tituloLabel.setForeground(new java.awt.Color(0, 0, 0));
        
        jPanel1.add(tituloLabel);
        tituloLabel.setBounds(300,5,200,150);

        //background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Menu/resources/fundoLogin.png"))); // NOI18N
        //background.setText("jLabel5");
        jPanel1.add(background);
        background.setBounds(0, 0, 340, 160);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void entrarBotaoActionPerformed(java.awt.event.ActionEvent evt) {                                            
               logar();
    }                                           
    
    private void sairBotaoActionPerformed(java.awt.event.ActionEvent evt) {                                          
        int escolha = JOptionPane.showConfirmDialog(null, "Deseja realmente sair?");
        if(escolha == 0){
        System.exit(0);       // TODO add your handling code here:
    }                                         
        else{
          JOptionPane.showMessageDialog(null, "Tome mais cuidado.");
        }}
    private void entrarBotaoKeyPressed(java.awt.event.KeyEvent evt) {                                       
             if (evt.getKeyCode() == KeyEvent.VK_ENTER) {  
               logar();
    }          // TODO add your handling code here:
    }                                      

    private void usuarioCampoKeyPressed(java.awt.event.KeyEvent evt) {                                        
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {  
                logar();
    }   // TODO add your handling code here:
    }                                       

    private void senhaCampoKeyPressed(java.awt.event.KeyEvent evt) {                                      
 if (evt.getKeyCode() == KeyEvent.VK_ENTER) {  
                    logar();
    }          // TODO add your handling code here:
    }                                     


    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogarSistema().setVisible(true);
                 
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton entrarBotao;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton sairBotao;
    private javax.swing.JPasswordField senhaCampo;
    private javax.swing.JLabel senhaLabel;
    private javax.swing.JLabel tituloLabel;
    private javax.swing.JTextField usuarioCampo;
    private javax.swing.JLabel usuarioLabel;
    // End of variables declaration                   

    }

